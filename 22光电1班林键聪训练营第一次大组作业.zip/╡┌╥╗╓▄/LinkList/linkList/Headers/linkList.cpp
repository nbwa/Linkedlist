#include "linkedList.h"
#include"stdlib.h"
#include"stdio.h"


Status InitList(LinkedList *L)
{
	int num,e;
	LinkedList p,r;
	if (L == NULL)
		return ERROR;
	(*L)->next = NULL;
	
	r = (*L);

	printf("Ҫ�����Ľ������");
		scanf_s("%d", &num);
		while (num < 1)
		{
			printf("������������������\n");
			scanf_s("%d", &num);
		}
		for (int i = 0; i < num; i++)
		{
			p = (LNode*)malloc(sizeof(LNode));
			printf("�������%d����㣺",i+1);
			scanf_s("%d", &e);
			p->data = e;
			p->next = r->next;
			r->next = p;
			r = p;
		}
	return SUCCESS;
}

void DestroyList(LinkedList* L)
{
	LNode* p, *q;
	p = (*L)->next;
	while (p)
	{
		q= p->next;
		p = q;
	}
}

Status bianli(LinkedList L)
{
	int n;
	LNode* p;
	LNode* q;
	q = (LNode*)malloc(sizeof(LinkedList));
	printf("������������ݵ�λ�ã�");
		scanf_s("%d", &n);
	printf("������Ҫ����Ľ�����ݣ�");
	scanf_s("%d", &(q->data));
	p = L;

	for (int i = 0; i < n; i++)
	{
		p = p->next;
		if (p == NULL)
		{
			printf("������������²���\n");

			return ERROR;
		}
	}
	InsertList(p, q);
	printf("����ɹ�");
	return SUCCESS;

}

Status InsertList(LNode* p, LNode* q)
{
	q->next = p->next;
	p->next = q;

	return SUCCESS;
}


Status Delete(LinkedList L)
{
	ElemType e;
//	e = NULL;
	int n;
	LNode* p;
	printf("������Ҫɾ�����ݵ�λ�ã�");
	scanf_s("%d", &n);
	if (n < 1)
	{
		printf("������������²���");

			return ERROR;
	}
	p = L;
	for (int i = 0; i < n - 1; i++)
	{
		p = p->next;
		if (p->next == NULL)
		{
			printf("�����������������\n");

			return ERROR;
		}
	}
	DeleteList(p, &e);
	printf("ɾ���ɹ�");
	return SUCCESS;

}

Status DeleteList(LNode* p, ElemType* e)
{
	LNode* q;
	q = p->next;
	(*e) = q->data;
	p->next = q->next;
	return SUCCESS;
}

void visit(ElemType e)
{
	printf("%d->", e);
}

void TraverseList(LinkedList L, void (*visit)(ElemType e))
{
	int e;
	LinkedList p;
	p = L->next;
	while (p)
	{
		e = p->data;
		visit(e);
		p = p->next;
	}
	printf("NULL\n");
}



Status SearchList(LinkedList L, ElemType e)
{
	LinkedList p;
	p = L;
	while (p->next!=NULL)
	{
		p = p->next;
		if (p->data == e)
		{
			printf("���ڴ˽��\n");
			return SUCCESS;
		}
	}
	printf("�����ڴ˽��\n");
	return SUCCESS;
}

Status ReverseList(LinkedList* L)
{
	LinkedList temp1,temp2,temp3;
	temp1 = (LinkedList)malloc(sizeof(LNode));

	temp1 = NULL;
	temp2 = (*L);

	while (temp2)
	{
		temp3 = temp2->next;

		temp2->next = temp1;
		if (temp2->next == (*L))
			temp2->next = NULL;

		temp1 = temp2;
		temp2 = temp3;
	}
	(*L)->next = temp1;
	return SUCCESS;
}

Status LoopList(LinkedList* L)
{
	LinkedList p;
	p = (*L);
	while (p->next)
		p = p->next;

	p->next = (*L);
	return SUCCESS;
}


Status IsLoopList(LinkedList L)
{
	int flag = 0;
	LinkedList p, q;
	p = q =L;
	while (p && p->next)
	{
		p = p->next->next;
		q = q->next;
		if (p == q)
		{
			flag = 1;
			break;
		}
	}
	if (flag == 1)
		printf("�����ɻ�\n");
	else
		printf("����δ�ɻ�\n");

	return SUCCESS;
}

//LNode* ReverseEvenList(LinkedList* L)
//{
//	LinkedList temp, first, second;
//	first =  second = (*L)->next;
//	temp = (*L);
//	while (first->next || second->next)
//	{
//		if (first->data != 1)
//		{
//			while (((first->data) % 2 == 0) && (first->next))
//			{
//				first = first->next;
//			}
//		}
//
//		if (second->data == 1)
//			second = second->next;
//		while (((second->data) % 2 == 1) && (second->next))
//		{
//			second = second->next;
//		}
//
//		if (first->next)
//		{
//			temp->next = first;
//			temp = temp->next;
//			first = first->next;
//		}
//		if (second->next)
//		{
//			temp->next = second;
//			temp = temp->next;
//			second = second->next;
//		}
//	}
//	return temp;
//}

LNode* FindMidNode(LinkedList* L)
{
	int num;
	LNode* p, * q;
	p = q = (*L);
	while (p && p->next)
	{
		p = p->next->next;
		q = q->next;
	}
	num = q->data;
	printf("�м�������Ϊ��%d\n", num);

	return q;
	
}


